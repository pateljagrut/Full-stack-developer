let arr = ["dev chauhan",
    {
        name: "dev chauhan",
        phone: "9726536518",
        nestedObj: {
            key1: "value1",
            array: [1, 2, 3, 4, 5]
        }
    }
]


let arr2 = [...arr]
arr2[0] = "dev patel"

let arr3 = [...arr2, 3, 4, 5, 6, "dev patel"]

arr2 = arr2.concat(arr3)

// console.log("array", arr,
//     arr[1].nestedObj.array[2]);

let arr4 = [2, 4, 6, 1]
let foundItem = arr4.some(
    (item) => item % 2 != 0
)

let arrayOfObj = [{
    name: "dev chauhan",
    phone: "9726536518",
    isAuthorized: true,
},
{
    name: "dev Patel",
    phone: "9726536518",
    isAuthorized: false,
},
{
    name: "Deep PAtel",
    phone: "9726536518",
    isAuthorized: true,
},
{
    name: "krish patel",
    phone: "9726536518",
    isAuthorized: true,
},
{
    name: "Jay Patel",
    phone: "9726536518",
    isAuthorized: false,
},
]

let foundItem2 = arr4.filter(
    (item) => item % 2 == 0
)

// console.log("array4", arr4,
//     foundItem
//     ,foundItem2);

let arrayObj2 = arrayOfObj.filter(
    (item, index) => index > 2
)



// console.log("arrayOfObj",arrayOfObj,arrayObj2);

// push , pop, join , reduce ,map

let arr5 = [1, 2, 3, 4, 5]
arr5.push(6)
console.log("push", arr5);
let popedItem = arr5.pop()
console.log("pop",
    popedItem, arr5);

let joinedItem = arr5.join("    ")
console.log("join", joinedItem)


let reducedItem = ["a", "b", "c", "d"].reduce(
    (acc, curr) => acc + curr
)

// 1 2 3 4 5 6 
// 1+2 = 3
// 3 +3 = 6
// 

console.log("reducedItem", reducedItem)


let MappedArray = arr5.map((item, index) => {
    // return index > 2 ? item : null
    if (index > 2)
        return item * 2
})

console.log("MappedArray", MappedArray)
