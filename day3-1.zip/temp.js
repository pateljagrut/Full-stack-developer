
let name = document.getElementById("name")
let phone = document.getElementById("phone")
let email = document.getElementById("email")
let body = document.getElementById("tbodyID")
let data = []

function onSubmit() {
    console.log("data", name.value, phone.value, email.value)
    data.push({ name: name.value, phone: phone.value, email: email.value })
    body.innerHTML = ""
    data.forEach((item, index) => {
        body.innerHTML += `<tr>
                <td>${item.name}</td>
                <td>${item.phone}</td>
                <td>${item.email}</td>
                <td>
                    <button type="button" onClick="onDelete(${index})">Delete</button>
                </td>
                </tr>`
    })
}

function objfun() {
    console.log("objfun called")
    return true
}


let myObj = {
    name: "dev chauhan",
    phone: "9726536518",
    fun : objfun,
    nestedObj :{
        key1 :"value1",
        array : [1,2,3,4,5]
    }
}

// spread operator
let myObj2 = {...myObj,address:"India"}

myObj2.name = "Nandini Parekh"
myObj2.nestedObj =[]


console.log("function example "
    ,myObj.fun())





    console.log(">>>>>>>", 
    Object.values(myObj),
    Object.keys(myObj),
    Object.entries(myObj)
)