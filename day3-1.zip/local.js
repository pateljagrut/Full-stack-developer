// localStorage.setItem("key1", JSON.stringify([1,2,3,4,5]));

let localItem = localStorage.getItem("key1");

console.log(JSON.parse(localItem))

document.getElementById("local").innerHTML = `<h3>${localItem}</h3>`